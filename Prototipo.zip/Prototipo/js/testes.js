function ValidaLogin(frm) {
    if (frm.email.value == "" || frm.email.value == null) {
        frm.email.focus();
        document.getElementById('email').style = 'border: 1px solid #FF0000';
        return false;
    }
    if (frm.senha.value == "" || frm.senha.value == null) {
        frm.senha.focus();
        document.getElementById('senha').style = 'border: 1px solid #FF0000';
        return false;
    }

    if (frm.email.value == "user@area.com" && frm.senha.value == "123456") {
        window.open('index3.html');
    } else {
        window.alert('Login ou senha inválidos!');
        return false;
    }
}

function duplicarCampos(){
	var clone = document.getElementById('origem').cloneNode(true);
	var destino = document.getElementById('destino');
	destino.appendChild (clone);
	var camposClonados = clone.getElementsByTagName('input');
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
}
function removerCampos(id){
	var node1 = document.getElementById('destino');
	node1.removeChild(node1.childNodes[0]);
}

$(document).ready(function() {

    console.log('    ______     __    __     ______     ______     ______      ______   ______     ______     ______   ______     ______     __  __    ');
    console.log('    /\  ___\   /\ "-./  \   /\  __ \   /\  == \   /\__  _\    /\  ___\ /\  __ \   /\  ___\   /\__  _\ /\  __ \   /\  == \   /\ \_\ \   ');
    console.log('    \ \___  \  \ \ \-./\ \  \ \  __ \  \ \  __<   \/_/\ \/    \ \  __\ \ \  __ \  \ \ \____  \/_/\ \/ \ \ \/\ \  \ \  __<   \ \____ \  ');
    console.log('     \/\_____\  \ \_\ \ \_\  \ \_\ \_\  \ \_\ \_\    \ \_\     \ \_\    \ \_\ \_\  \ \_____\    \ \_\  \ \_____\  \ \_\ \_\  \/\_____\ ');
    console.log('      \/_____/   \/_/  \/_/   \/_/\/_/   \/_/ /_/     \/_/      \/_/     \/_/\/_/   \/_____/     \/_/   \/_____/   \/_/ /_/   \/_____/ ');

    console.log('');
    console.log('');

    console.log('Desenvolvido por Danielle, Eduardo, Leticia, Marcus e Mayara');

});

function menu() {

    document.write('  <ul class="nav menu">');
    document.write('    <li class="active"><a href="index2.html"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Painel de Controle</a></li>');
    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-clientes"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Clientes');
    document.write('      </a>');
    document.write('      <ul class="children" id="sub-item-clientes">');
    document.write('        <li>');
    document.write('          <a class="" href="clientes_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Clientes');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="clientes_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Cliente');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-venda"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Vendas');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-venda">');
    document.write('        <li>');
    document.write('          <a class="" href="vendas_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Vendas');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="vendas_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Venda');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-fornecedores"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Fornecedores');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-fornecedores">');
    document.write('        <li>');
    document.write('          <a class="" href="fornecedores_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Listar Fornecedores');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="fornecedores_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Fornecedor');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-produto"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Produtos');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-produto">');
    document.write('        <li>');
    document.write('          <a class="" href="produtos_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Lista de Produtos');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="produtos_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Produto');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="produtos_ordemproducao.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Orderm de Produção');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-materia"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Matéria Prima');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-materia">');
    document.write('        <li>');
    document.write('          <a class="" href="matprima_compra.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Ordem de Compra');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="matprima_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="matprima_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Em Estoque');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-materia"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Estoque');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-estoque">');
    document.write('        <li>');
    document.write('          <a class="" href="estoque_pedidos.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Pedidos de Produção');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="estoque_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Itens em estoque');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-producao"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Produção');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-producao">');
    document.write('        <li>');
    document.write('          <a class="" href="producao_ordens.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Ordens de Produção');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="producao_simulacao_tempo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Simulação - Tempo');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="producao_simulacao_desperdicio.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Simulação - Desperdicio');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-usuarios"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Usuários');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-usuarios">');
    document.write('        <li>');
    document.write('          <a class="" href="usuarios_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Usuários');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="usuarios_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Lista');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');

    document.write('    <li class="parent ">');
    document.write('      <a href="#">');
    document.write('        <span data-toggle="collapse" href="#sub-item-filial"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Filiais');
    document.write('      </a>');
    document.write('      <ul class="children " id="sub-item-filial">');
    document.write('        <li>');
    document.write('          <a class="" href="filial_novo.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Cadastrar Filial');
    document.write('          </a>');
    document.write('        </li>');
    document.write('        <li>');
    document.write('          <a class="" href="filial_lista.html">');
    document.write('            <svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Lista de Filiais');
    document.write('          </a>');
    document.write('        </li>');
    document.write('      </ul>');
    document.write('    </li>');
    document.write('  </ul>');

}
/*
(function() {
*/
function SimularTempo(){
    document.getElementById('simula').style = 'display: block;';

    var node = document.getElementById('message'),
    message = "Produto enviado para produção...\n";
    message += "Ordem de produção recebida...\n";
    message += "Máterias primas em falta...\n";
    message += "Gerando ordens de compra de máteria-prima...\n";
    message += "Máteria-Prima comprada do Fornecer 01, tempo médio de entrega 2 dias...\n";
    message += "Começa a produção do produto solicitado...";
    message += "Produto enviado para transporte...";
    message += "Produto enviado para cliente...";
    message += ".........................................................................";
    message += "Tempo total do produto 15 dias";
    current = message.split("").reverse(),
    interval = setInterval(function() {
      if (current.length)
        node.innerHTML += current.pop();
      else
        clearInterval(interval);
    }, 50);

}

function SimularDesperdicio(){
    document.getElementById('simula').style = 'display: block;';

    var node = document.getElementById('message'),
    message = "Produto enviado para produção...\n";
    message += "Ordem de produção recebida...\n";
    message += "Máterias primas em falta...\n";
    message += "Gerando ordens de compra de máteria-prima...\n";
    message += "Máteria-Prima comprada do Fornecer 01, tempo médio de entrega 2 dias...\n";
    message += "Começa a produção do produto solicitado...";
    message += "Produto enviado para transporte...";
    message += "Produto enviado para cliente...";
    message += ".........................................................................";
    message += "Total de matéria-prima desperdiçada... XX - Máteria-Prima 01...XX - Máteria-Prima 03...XX - Máteria-Prima 04...XX - Máteria-Prima 02";
    current = message.split("").reverse(),
    interval = setInterval(function() {
      if (current.length)
        node.innerHTML += current.pop();
      else
        clearInterval(interval);
    }, 50);
}

function BuscarFornecedor(){
    document.getElementById('fornecedor').style = 'display: block';
}